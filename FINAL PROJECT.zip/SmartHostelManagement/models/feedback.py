from pydantic import BaseModel, Field

class Feedback(BaseModel):
    rating: int = Field(..., ge=1, le=5)
    comment: str
    complaintId: str