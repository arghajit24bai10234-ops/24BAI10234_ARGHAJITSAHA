from pydantic import BaseModel

class Complaint(BaseModel):
    title: str
    description: str
    status: str
    priority: str
    studentId: str
    staffId: str | None = None