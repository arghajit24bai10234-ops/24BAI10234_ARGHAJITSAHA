from pydantic import BaseModel, Field

class Student(BaseModel):
    name: str
    email: str
    phone: str = Field(..., pattern=r"^\d{10}$")
    roomNo: str
    blockNo: str