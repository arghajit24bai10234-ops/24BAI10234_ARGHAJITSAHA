from pydantic import BaseModel

class HostelBlock(BaseModel):
    blockName: str
    floorCount: int
    staffIds: list[str] = []