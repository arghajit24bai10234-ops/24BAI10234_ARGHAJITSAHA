from fastapi import FastAPI
from routes.student_routes import router
from routes.department_routes import router as department_router
from routes.staff_routes import router as staff_router
from routes.complaint_routes import router as complaint_router
from routes.feedback_routes import router as feedback_router
from routes.hostelblock_routes import router as hostelblock_router



app = FastAPI()

app.include_router(router)
app.include_router(department_router)
app.include_router(staff_router)
app.include_router(complaint_router)
app.include_router(feedback_router)
app.include_router(hostelblock_router)


@app.get("/")
def home():
    return {
        "message": "Smart Hostel Management & Complaint Tracking System"
    }