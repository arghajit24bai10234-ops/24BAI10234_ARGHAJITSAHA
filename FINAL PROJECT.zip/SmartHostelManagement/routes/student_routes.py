from fastapi import APIRouter
from models.student import Student
from database import db
from bson import ObjectId

router = APIRouter(tags=["Students"])

students_collection = db["students"]

@router.post("/students")
def create_student(student: Student):

    student_dict = student.dict()

    result = students_collection.insert_one(student_dict)

    return {
        "message": "Student Added Successfully",
        "id": str(result.inserted_id)
    }

@router.get("/students")
def get_students():

    students = []

    for student in students_collection.find():

        student["_id"] = str(student["_id"])

        students.append(student)

    return students

@router.get("/students/{student_id}")
def get_student(student_id: str):

    student = students_collection.find_one(
        {"_id": ObjectId(student_id)}
    )

    if student:

        student["_id"] = str(student["_id"])

        return student

    return {"message": "Student Not Found"}

@router.put("/students/{student_id}")
def update_student(student_id: str, student: Student):

    result = students_collection.update_one(
        {"_id": ObjectId(student_id)},
        {"$set": student.model_dump()}
    )

    if result.modified_count:

        return {"message": "Student Updated Successfully"}

    return {"message": "Student Not Found"}

@router.delete("/students/{student_id}")
def delete_student(student_id: str):

    result = students_collection.delete_one(
        {"_id": ObjectId(student_id)}
    )

    if result.deleted_count:

        return {"message": "Student Deleted Successfully"}

    return {"message": "Student Not Found"}

@router.get("/hostelblocks/{block_name}/students")
def get_students_by_block(block_name: str):

    students = []

    for student in students_collection.find(
        {"blockNo": block_name}
    ):

        student["_id"] = str(student["_id"])

        students.append(student)

    return students