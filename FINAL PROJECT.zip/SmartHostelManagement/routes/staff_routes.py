from fastapi import APIRouter
from database import db
from models.staff import Staff
from bson import ObjectId

router = APIRouter( tags=["Staff"])

staff_collection = db["staff"]

@router.post("/staff")
def create_staff(staff: Staff):

    result = staff_collection.insert_one(
        staff.model_dump()
    )

    return {
        "message": "Staff Added Successfully",
        "id": str(result.inserted_id)
    }

@router.get("/staff")
def get_staff():

    staffs = []

    for staff in staff_collection.find():

        staff["_id"] = str(staff["_id"])

        staffs.append(staff)

    return staffs

@router.get("/staff/{staff_id}")
def get_staff_by_id(staff_id: str):

    staff = staff_collection.find_one(
        {"_id": ObjectId(staff_id)}
    )

    if staff:

        staff["_id"] = str(staff["_id"])

        return staff

    return {"message": "Staff Not Found"}

@router.put("/staff/{staff_id}")
def update_staff(
    staff_id: str,
    staff: Staff
):

    result = staff_collection.update_one(
        {"_id": ObjectId(staff_id)},
        {"$set": staff.model_dump()}
    )

    if result.modified_count:

        return {
            "message": "Staff Updated Successfully"
        }

    return {"message": "Staff Not Found"}

@router.delete("/staff/{staff_id}")
def delete_staff(staff_id: str):

    result = staff_collection.delete_one(
        {"_id": ObjectId(staff_id)}
    )

    if result.deleted_count:

        return {
            "message": "Staff Deleted Successfully"
        }

    return {"message": "Staff Not Found"}

@router.get("/departments/{department_id}/staff")
def get_department_staff(department_id: str):

    staffs = []

    for staff in staff_collection.find(
        {"departmentId": department_id}
    ):

        staff["_id"] = str(staff["_id"])

        staffs.append(staff)

    return staffs