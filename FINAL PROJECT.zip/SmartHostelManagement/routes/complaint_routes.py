from fastapi import APIRouter
from database import db
from models.complaint import Complaint
from bson import ObjectId

router = APIRouter( tags=["Complaints"])

complaint_collection = db["complaints"]

@router.post("/complaints")
def create_complaint(complaint: Complaint):

    result = complaint_collection.insert_one(
        complaint.model_dump()
    )

    return {
        "message": "Complaint Registered Successfully",
        "id": str(result.inserted_id)
    }

@router.get("/complaints")
def get_complaints():

    complaints = []

    for complaint in complaint_collection.find():

        complaint["_id"] = str(complaint["_id"])

        complaints.append(complaint)

    return complaints

@router.get("/complaints/{complaint_id}")
def get_complaint(complaint_id: str):

    complaint = complaint_collection.find_one(
        {"_id": ObjectId(complaint_id)}
    )

    if complaint:

        complaint["_id"] = str(complaint["_id"])

        return complaint

    return {"message": "Complaint Not Found"}

@router.put("/complaints/{complaint_id}")
def update_complaint(
    complaint_id: str,
    complaint: Complaint
):

    result = complaint_collection.update_one(
        {"_id": ObjectId(complaint_id)},
        {"$set": complaint.model_dump()}
    )

    if result.modified_count:

        return {
            "message": "Complaint Updated Successfully"
        }

    return {"message": "Complaint Not Found"}

@router.delete("/complaints/{complaint_id}")
def delete_complaint(complaint_id: str):

    result = complaint_collection.delete_one(
        {"_id": ObjectId(complaint_id)}
    )

    if result.deleted_count:

        return {
            "message": "Complaint Deleted Successfully"
        }

    return {"message": "Complaint Not Found"}

@router.get("/students/{student_id}/complaints")
def get_student_complaints(student_id: str):

    complaints = []

    for complaint in complaint_collection.find(
        {"studentId": student_id}
    ):

        complaint["_id"] = str(complaint["_id"])

        complaints.append(complaint)

    return complaints

@router.put("/complaints/{complaint_id}/assign/{staff_id}")
def assign_staff(
    complaint_id: str,
    staff_id: str
):

    result = complaint_collection.update_one(
        {"_id": ObjectId(complaint_id)},
        {
            "$set": {
                "staffId": staff_id,
                "status": "In Progress"
            }
        }
    )

    if result.modified_count:

        return {
            "message": "Staff Assigned Successfully"
        }

    return {
        "message": "Complaint Not Found"
    }

@router.put("/complaints/{complaint_id}/resolve")
def resolve_complaint(complaint_id: str):

    result = complaint_collection.update_one(
        {"_id": ObjectId(complaint_id)},
        {"$set": {"status": "Resolved"}}
    )

    if result.modified_count:

        return {
            "message": "Complaint Resolved Successfully"
        }

    return {
        "message": "Complaint Not Found"
    }