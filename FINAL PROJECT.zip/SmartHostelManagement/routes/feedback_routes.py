from fastapi import APIRouter
from database import db
from models.feedback import Feedback
from bson import ObjectId

router = APIRouter(tags=["Feedback"])

feedback_collection = db["feedback"]

@router.post("/feedback")
def create_feedback(feedback: Feedback):

    result = feedback_collection.insert_one(
        feedback.model_dump()
    )

    return {
        "message": "Feedback Added Successfully",
        "id": str(result.inserted_id)
    }

@router.get("/feedback")
def get_feedback():

    feedbacks = []

    for feedback in feedback_collection.find():

        feedback["_id"] = str(feedback["_id"])

        feedbacks.append(feedback)

    return feedbacks

@router.get("/feedback/{feedback_id}")
def get_feedback_by_id(feedback_id: str):

    feedback = feedback_collection.find_one(
        {"_id": ObjectId(feedback_id)}
    )

    if feedback:

        feedback["_id"] = str(feedback["_id"])

        return feedback

    return {
        "message": "Feedback Not Found"
    }

@router.put("/feedback/{feedback_id}")
def update_feedback(
    feedback_id: str,
    feedback: Feedback
):

    result = feedback_collection.update_one(
        {"_id": ObjectId(feedback_id)},
        {"$set": feedback.model_dump()}
    )

    if result.modified_count:

        return {
            "message": "Feedback Updated Successfully"
        }

    return {
        "message": "Feedback Not Found"
    }

@router.delete("/feedback/{feedback_id}")
def delete_feedback(feedback_id: str):

    result = feedback_collection.delete_one(
        {"_id": ObjectId(feedback_id)}
    )

    if result.deleted_count:

        return {
            "message": "Feedback Deleted Successfully"
        }

    return {
        "message": "Feedback Not Found"
    }

@router.get("/complaints/{complaint_id}/feedback")
def get_complaint_feedback(complaint_id: str):

    feedback = feedback_collection.find_one(
        {"complaintId": complaint_id}
    )

    if feedback:

        feedback["_id"] = str(feedback["_id"])

        return feedback

    return {
        "message": "Feedback Not Found"
    }