from fastapi import APIRouter
from database import db
from models.hostelblock import HostelBlock
from bson import ObjectId

router = APIRouter(tags=["Hostel Blocks"])

hostelblock_collection = db["hostelblocks"]
staff_collection = db["staff"]


@router.post("/hostelblocks")
def create_block(block: HostelBlock):

    result = hostelblock_collection.insert_one(
        block.model_dump()
    )

    return {
        "message": "Hostel Block Added Successfully",
        "id": str(result.inserted_id)
    }

@router.get("/hostelblocks")
def get_blocks():

    blocks = []

    for block in hostelblock_collection.find():

        block["_id"] = str(block["_id"])

        blocks.append(block)

    return blocks

@router.get("/hostelblocks/{block_id}")
def get_block(block_id: str):

    block = hostelblock_collection.find_one(
        {"_id": ObjectId(block_id)}
    )

    if block:

        block["_id"] = str(block["_id"])

        return block

    return {"message": "Block Not Found"}

@router.put("/hostelblocks/{block_id}")
def update_block(block_id: str, block: HostelBlock):

    result = hostelblock_collection.update_one(
        {"_id": ObjectId(block_id)},
        {"$set": block.model_dump()}
    )

    if result.modified_count:

        return {"message": "Block Updated Successfully"}

    return {"message": "Block Not Found"}

@router.delete("/hostelblocks/{block_id}")
def delete_block(block_id: str):

    result = hostelblock_collection.delete_one(
        {"_id": ObjectId(block_id)}
    )

    if result.deleted_count:

        return {"message": "Block Deleted Successfully"}

    return {"message": "Block Not Found"}

@router.get("/hostelblocks/{block_id}/staff")
def get_block_staff(block_id: str):

    block = hostelblock_collection.find_one(
        {"_id": ObjectId(block_id)}
    )

    if not block:
        return {"message": "Block Not Found"}

    staff_details = []

    for staff_id in block["staffIds"]:

        staff = staff_collection.find_one(
            {"_id": ObjectId(staff_id)}
        )

        if staff:

            staff_details.append({
                "staffId": str(staff["_id"]),
                "name": staff["name"],
                "role": staff["role"]
            })

    return {
        "blockName": block["blockName"],
        "staff": staff_details
    }