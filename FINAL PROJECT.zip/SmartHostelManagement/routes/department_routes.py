from fastapi import APIRouter
from database import db
from models.department import Department
from bson import ObjectId

router = APIRouter(tags=["Departments"])

department_collection = db["departments"]

@router.post("/departments")
def create_department(department: Department):

    result = department_collection.insert_one(
        department.model_dump()
    )

    return {
        "message": "Department Added Successfully",
        "id": str(result.inserted_id)
    }

@router.get("/departments")
def get_departments():

    departments = []

    for department in department_collection.find():

        department["_id"] = str(department["_id"])

        departments.append(department)

    return departments

@router.get("/departments/{department_id}")
def get_department(department_id: str):

    department = department_collection.find_one(
        {"_id": ObjectId(department_id)}
    )

    if department:

        department["_id"] = str(department["_id"])

        return department

    return {"message": "Department Not Found"}

@router.put("/departments/{department_id}")
def update_department(
    department_id: str,
    department: Department
):

    result = department_collection.update_one(
        {"_id": ObjectId(department_id)},
        {"$set": department.model_dump()}
    )

    if result.modified_count:

        return {
            "message": "Department Updated Successfully"
        }

    return {"message": "Department Not Found"}

@router.delete("/departments/{department_id}")
def delete_department(department_id: str):

    result = department_collection.delete_one(
        {"_id": ObjectId(department_id)}
    )

    if result.deleted_count:

        return {
            "message": "Department Deleted Successfully"
        }

    return {"message": "Department Not Found"}